#!/bin/bash
DEBUG=todos:* npm start
